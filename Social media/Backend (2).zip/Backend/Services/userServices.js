var users = require("../models/userModel");
var mongoose = require("mongoose");
var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var jsonParser = bodyParser.json();
app.use(jsonParser);
const userService = {
  register: async (user) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var uDoc = await users.create(user);
    mongoose.connection.close();
    return uDoc;
  },
  login: async (uid, pwd) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var user = await users.findOne({ userID: uid, password: pwd });
    return user;
    mongoose.connection.close();
  },
  deleteUser: async (id) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var user = await users.findByIdAndDelete(id);
    return user;
    mongoose.connection.close();
  },
  getUser: async (id) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var user = await users.findOne({ userID: id });
    return user;
    mongoose.connection.close();
  },
  updateUser: async (id, about) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var user = await users.updateOne({ userID: id }, { about: about });
    return user;
    mongoose.connection.close();
  },
};
module.exports = userService;
/*


app.put("/profile/:userID", (req, res) => {
  var { name, email, password, about } = req.body;
  const id = req.params.userID;
  async function updateUser() {
    
  }
  updateUser();
});


*/
