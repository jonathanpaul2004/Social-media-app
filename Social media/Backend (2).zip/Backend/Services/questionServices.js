var questions = require("../models/questionModel");
var mongoose = require("mongoose");
var express = require("express");
var app = express();
var cors = require("cors");
var bodyParser = require("body-parser");
var jsonParser = bodyParser.json();
app.use(jsonParser);
app.use(cors());
const questionService = {
  post: async (question) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var qDoc = await questions.create(question);
    mongoose.connection.close();
    return qDoc;
  },
  deleteQues: async (id) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var user = await questions.findByIdAndDelete(id);
    var delAns = await answers.deleteMany({ questionid: id });
    return user;
    mongoose.connection.close();
  },
  updateQues: async (id, ques) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var upd = await questions.findByIdAndUpdate(id, { question: ques });
    return upd;
    mongoose.connection.close();
  },
  getQues: async (cat) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var upd = await questions.find({ category: cat });
    return upd;
    mongoose.connection.close();
  },
};
module.exports = questionService;
