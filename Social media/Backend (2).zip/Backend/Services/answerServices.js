var answers = require("../models/answerModel");
var mongoose = require("mongoose");
var express = require("express");
var app = express();
var cors = require("cors");
var bodyParser = require("body-parser");
var jsonParser = bodyParser.json();
app.use(jsonParser);
app.use(cors());
const answerService = {
  postAns: async (id, ans) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var qDoc = await answers.create({
      answer: ans,
      questionid: id,
    });
    mongoose.connection.close();
    return qDoc;
  },
  deleteAns: async (id) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var user = await answers.findByIdAndDelete(id);
    return user;
    mongoose.connection.close();
  },
  updateAns: async (id, ans) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var upd = await answers.updateOne({ questionid: id }, { answer: ans });
    return upd;
    mongoose.connection.close();
  },
  getAns: async (id) => {
    await mongoose.connect("mongodb://127.0.0.1:27017/test");
    var upd = await answers.find({ questionid: id });
    return upd;
    mongoose.connection.close();
  },
};
module.exports = answerService;
