var questionServices = require("../Services/questionServices");
var express = require("express");
var app = express();
var cors = require("cors");
var bodyParser = require("body-parser");
var jsonParser = bodyParser.json();
var router = express.Router();
router.use(jsonParser);
app.use(cors());

router.post("/question", async (req, res) => {
  const ques = await questionServices.post(req.body);
  res.send(ques);
});

router.delete("/question/:id", async (req, res) => {
  const del = await questionServices.deleteQues(req.params.id);
  res.send(del);
});

router.put("/question/:id", async (req, res) => {
  const { question } = req.body;
  const upd = await questionServices.updateQues(req.params.id, question);
  res.send(upd);
});

router.get("/question/:category", async (req, res) => {
  const getQ = await questionServices.getQues(req.params.category);
  res.send(getQ);
});

module.exports = router;
